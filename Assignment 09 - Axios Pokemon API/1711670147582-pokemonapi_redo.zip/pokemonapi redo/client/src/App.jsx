import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [pokeData, setPokeData] = useState([]);

  useEffect( () => {
    axios.get('https://pokeapi.co/api/v2/pokemon?limit=151')
      .then( response => {
        console.log(response.data.results)
        setPokeData(response.data.results)
      })
        .catch( err => {
        console.log(err)
        })
    }, [] )


  return (
    <div>
      <h1>List of 151 Pokemon</h1>
      <ul>
        {pokeData.map((item, index) => (
          <li key={index}>{item.name}</li>
        ))}
      </ul>
    </div>
  )
}

export default App;