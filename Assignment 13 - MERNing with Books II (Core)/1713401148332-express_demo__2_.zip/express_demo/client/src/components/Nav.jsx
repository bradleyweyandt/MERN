import React from 'react'
import {Link} from 'react-router-dom'

const nav = () => {
  return (
    <div>
        <Link to="/">Catalog</Link>
        <Link to="/create">Add Book</Link>
    </div>
  )
}

export default nav