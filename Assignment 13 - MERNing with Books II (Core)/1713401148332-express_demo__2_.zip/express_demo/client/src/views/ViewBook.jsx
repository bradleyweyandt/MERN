import { useParams, useNavigate } from 'react-router-dom'
import {React, useState, useEffect} from 'react'
import axios from 'axios'

function ViewBook() {
    const { id } = useParams()
    const navigate = useNavigate()
    const [book, setBook] = useState({
        title: "",
        pagecount: 0,
        author: ""
    })

    useEffect( () => {
        axios.get(`http://localhost:8000/api/book/${id}`)
        .then( response => {
            console.log(response)
            setBook(response.data)
        })
        .catch( err => {
            console.log(err)
        })
    }, [])

    const handleDelete = () => {
        axios.delete(`http://localhost:8000/api/book/${id}`)
        .then( response => {
            console.log(response)
            navigate("/")
        })
        .catch( err => {
            console.log(err)
        })
    }

  return (
    <div>
        <h1>Title: {book.title}</h1>
        <h1>Author: {book.author}</h1>
        <p>Page Count: {book.pagecount}</p>
        <button onClick={handleDelete}>Borrow</button>
    </div>
  )
}

export default ViewBook