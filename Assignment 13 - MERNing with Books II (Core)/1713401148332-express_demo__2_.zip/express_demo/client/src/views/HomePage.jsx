import {React, useState, useEffect} from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'

const HomePage = () => {
    const [books, setBooks] = useState([])

    useEffect( () => {
    axios.get("http://localhost:8000/api/books")
        .then(response => {
        console.log(response.data)
        setBooks(response.data)
    })
    .catch()
}, [])

    return (
        <div>
        <table>
            <thead>
                <tr>
                    <th>Book</th>
                    <th>Author</th>
                    {/* <th>In Stock</th> */}
                    <th>Page Count</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                {books.map((book) => (
                <tr key={book._id}>
                    <td>{book.title}</td>
                    <td>{book.author}</td>
                    <td>{book.pagecount}</td>
                    {/* <td>{product.inStock ? <p>Yes</p> : <p>No</p>} </td> */}
                    <td>
                        <Link to={`/dets/${book._id}`}>Details</Link>
                        <Link to={`/update/${book._id}`}>Edit</Link>
                    </td>
                </tr>
                ))}
            </tbody>
        </table>
                    {
        books.map( (book) => (
            <div key={book._id}>
                <h2>Book Available: {book.title}</h2>
            </div>
        ))
    }
    </div>
    )
}

export default HomePage