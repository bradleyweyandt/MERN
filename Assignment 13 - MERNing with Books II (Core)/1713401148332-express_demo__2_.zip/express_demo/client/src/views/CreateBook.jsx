import {React, useState, useEffect} from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

const CreateBook = () => {
    const navigate = useNavigate()
    const [book, setBook] = useState({
        title: "",
        pagecount: 0,
        author: ""
    })

    const [errors, setErrors] = useState({})
// code for checkbox
const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    // For checkbox inputs, use the checked property to get the value
    const newValue = type === 'checkbox' ? checked : value;
    setBook({ ...book, [name]: newValue });
};

// const handleChange = (e) => {
//     setBook({...book, [e.target.name]:e.target.value})
// }

    const handleSubmit = (e) => {
        e.preventDefault()
        axios.post("http://localhost:8000/api/books", book)
            .then( response => {
                navigate ("/")
            }
            )
            .catch( err => {
                console.log(err)
                setErrors(err.response.data.errors)
            })
    }

  return (
    <div>
        {/* {
            errors.map( (item) => (
                <div>
                    <p>{item.message}</p>
                </div>
            ))
        } */}
        <div>
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="">Title: </label>
                    <input type="text" name="title" value={book.title} onChange={handleChange} />
                    <p>{ errors.title ? errors.title.message: null}</p>
                    </div>
                    <div>
                    <label htmlFor="">Author: </label>
                    <input type="text" name="author" value={book.author} onChange={handleChange} />
                    <p>{ errors.author ? errors.author.message: null}</p>
                    </div>
                    <div>
                    <label htmlFor="">Page Count: </label>
                    <input type="number" name="pagecount" value={book.pagecount} onChange={handleChange} />
                    <p>{ errors.pagecount ? errors.pagecount.message: null}</p>
                    </div>
                    <div>
                        <label>
                            Is the book available?:
                            <input type="checkbox" name="isAvailable" checked={book.isAvailable} onChange={handleChange} />
                        </label>
                    </div>
                     {/* <input type="checkbox" name="inStock" checked={product.inStock} onChange={} /> */}
            <button>Submit</button>
        </form>
                </div>
        
            
            
            
           
    </div>
  )
}

export default CreateBook