import {React, useState, useEffect} from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import axios from 'axios'

const Update = () => {
    const { id } = useParams()
    const navigate = useNavigate()
    const [book, setBook] = useState({
        title: "",
        pagecount: 0,
        author: ""
    })

    useEffect(() => {
        axios.get(`http://localhost:8000/api/book/${id}`)
        .then(response => {
            console.log(response);
            setBook(response.data);
        })
        .catch(err => {
            console.log(err);
        });
    }, []);

    const handleChange = (e) => {
        setBook({...book, [e.target.name]:e.target.value})
    }

    const handleSubmit = (e) => {
        e.preventDefault()
        axios.put(`http://localhost:8000/api/book/${id}`, book)
            .then( response => {
                navigate ("/")
            }
            )
            .catch( err => {
                console.log(err)
            })
    }

  return (
    <div>
        <form onSubmit={handleSubmit}>
            <input type="text" name="title" value={book.title} onChange={handleChange} />
            <input type="text" name="author" value={book.author} onChange={handleChange} />
            <input type="number" name="pagecount" value={book.pagecount} onChange={handleChange} />
            {/* <input type="checkbox" name="inStock" checked={product.inStock} onChange={} /> */}
            <button>Submit</button>
        </form>
    </div>
  )
}

export default Update