import { useState, useEffect} from 'react'
import axios from 'axios'
import './App.css'
import HomePage from './views/HomePage'
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import CreateBook from './views/CreateBook'
import Nav from './components/Nav'
import Update from './views/Update'
import ViewBook from './views/ViewBook'

function App() {


    return (
    <>
        <BrowserRouter>
        <Nav />
        <Routes>
        <Route path={"/"} element={<HomePage />}/>
        <Route path={"/create"} element={<CreateBook />}/>
        <Route path={"/update/:id"} element={<Update />}/>
        <Route path={"/dets/:id"} element={<ViewBook />}/>
        </Routes>
        </BrowserRouter>
       
    </>
    )
}
export default App;