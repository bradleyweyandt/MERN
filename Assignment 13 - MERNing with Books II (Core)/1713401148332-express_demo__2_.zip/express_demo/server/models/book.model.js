import {model, Schema} from 'mongoose';

const BookSchema = new Schema({
    title: {
        type: String,
        required: [true, "Book Required"],
        minlength: [2, "Must be at least 2 characters"],
        maxlength: [10, "Must be less than 10 characters"]
    },

    pagecount:{
        type: Number,
        required: [true, "Page Count Required"]
    },

    author:{
        type: String,
        required: [true, "Author Required"],
        minlength: [2, "Must be at least 2 characters"],
        maxlength: [10, "Must be less than 10 characters"]
    },
    isAvailable: {
        type: Boolean,
        default: true
    }
    
    
},
{ timestamps: true }
);

const Book = model("Book", BookSchema)
export default Book