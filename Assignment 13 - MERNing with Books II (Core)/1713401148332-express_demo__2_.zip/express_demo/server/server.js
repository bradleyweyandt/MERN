// import express from "express";
// const app = express();
// const port = 8000;

// app.use( express.json() );

// const users = [
//     { firstName: "Bradley", lastName: "Weyandt", id:12344524}
// ];

// app.get("/api/users", (req, res) => {
//     res.json( users );
// });

// app.post("/api/add_user", (req, res) => {
//     console.log(req.body)
//     users.pugh(req.body)
//     res.json( { allUsers: users, newUser: req.body } )
// })

// app.get("/api/one_user/:userId", (req, res) => {
//     console.log(req.params.userId)
//     const user = users.filter((item) => item.id == req.params.userId)
//     res.json(user)
// })

// app.listen( port, () => console.log(`Listening on port: ${port}`) );

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import dbConnect from './config/mongoose.config.js';
import router from './routes/book.routes.js'

const app = express();

app.use(express.json(), cors());
app.use('/api', router);

dotenv.config();
const PORT = process.env.PORT;
dbConnect();
app.listen(PORT, () =>
    console.log(`Listening on port: ${PORT}`)
);