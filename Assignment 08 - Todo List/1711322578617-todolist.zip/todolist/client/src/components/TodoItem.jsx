import React from 'react';
import '../assets/css/TodoItem.css';

function TodoItem({ todo, toggleTodo, removeTodo }) {
  const { id, text, completed } = todo;

  return (
    <li className="todo-item" style={{ textDecoration: completed ? 'line-through' : 'none' }}>
      <div className="todo-content"> {}
        <span>{text}</span>
        <input type="checkbox" checked={completed} onChange={() => toggleTodo(id)} />
      </div>
      <button className="delete-button" onClick={() => removeTodo(id)}>Delete</button>
    </li>
  );
}

export default TodoItem;