// Problem 1
// Why did the code produce that output? If applicable, how would you get the index value that did not output?

const cars = ['Tesla', 'Mercedes', 'Honda']
const [ randomCar ] = cars
const [ ,otherRandomCar ] = cars
//Predict the output
console.log(randomCar)
console.log(otherRandomCar)

// Tesla, Mercedes
// the code is destructuring, Tesla went to randomCar, Honda went to otherRandomCar becaues of that space, comma. To get the index value that didnt output you could just assign it a variable and call it as done with the others


// Problem 2
// Why did the code produce that output? If applicable, what would you need to do to solve any potential problems?

const employee = {
    employeeName: 'Elon',
    age: 47,
    company: 'Tesla'
}
const { employeeName: otherName } = employee;
//Predict the output
console.log(otherName);
console.log(employeeName);

// Elon first and then I received the error, ReferenceError: employeeName is not defined, its not in the scope, you declare the variable


// Problem 3
// Why did the code produce that output? If applicable, how would you alter this code without changing either console.log?

const person = {
    name: 'Phil Smith',
    age: 47,
    height: '6 feet'
}
const password = '12345';
const { password: hashedPassword } = person;  
//Predict the output
console.log(password);
console.log(hashedPassword);

// 12345, undefined. There is no password to destructure from the person object. You could add a password property to the person object.


// Problem 4
// Why did the code produce that output? Declare a new variable for the value at the 4th index of the array and console.log it.

const numbers = [8, 2, 3, 5, 6, 1, 67, 12, 2];
const [,first] = numbers;
const [,,,second] = numbers;
const [,,,,,,,,third] = numbers;
//Predict the output
console.log(first === second);
console.log(first === third);

//first = 2, second = 5, thrid = 2, so false, true
const [,,,,fourth] = numbers;
console.log(fourth)

// Problem 5
// Why did the code produce that output? Console.log the last value in the secondKey property's array.

const lastTest = {
    key: 'value',
    secondKey: [1, 5, 1, 8, 3, 3]
}
const { key } = lastTest;
const { secondKey } = lastTest;
const [ ,willThisWork] = secondKey;
//Predict the output
console.log(key);
console.log(secondKey);
console.log(secondKey[0]);
console.log(willThisWork);

// value, pulls value of key, which is value
// [ 1, 5, 1, 8, 3, 3 ], lastTest object has property of secondKey which has value of this array
// 1, pull from  index of secondkey
// 5, comma skips 0 index, pulls 5

// Problem 6
// First, how many scopes does the following code block contain? Define each scope and guess what the output will be.

var beatles = ['Paul', 'George', 'John', 'Ringo'];
function printNames(names) {
  function actuallyPrintingNames() {
    for (var index = 0; index < names.length; index++) {
      var name = names[index];
      console.log(name + ' was found at index ' + index);
    }
    console.log('name and index after loop is ' + name + ':' + index);
  }
  actuallyPrintingNames();
}
printNames(beatles);

// 3 scopes, 1 is global, contains the variable beatles and function printNames, 2 printNames function, 3 function actuallyPrintingNames
// Paul was found at index 0, 
// George was found at index 1
// John was found at index 2
// Ringo was found at index 3
// name and index after loop is Ringo:4

// Problem 7
// Why did the code produce that output?

 function actuallyPrintingNames() {
  for (let index = 0; index < names.length; index++) {
    let name = names[index];
    console.log(name + ' was found at index ' + index);
  }
  console.log('name and index after loop is ' + name + ':' + index);
}     

// node, name and index are in the loop and are not accessible outside of it

// Problem 8
// Why did the code produce that output? Explain the output, including any possible errors and why they occurred. If there are no errors, explain the justification for each keyword used to declare variables.

const beatles = ['Paul', 'George', 'John', 'Ringo'];
function printNames(names) {
  function actuallyPrintingNames() {
    for (let index = 0; index < names.length; index++) {
      const name = names[index];
      console.log(name + ' was found at index ' + index);
    }
  }
  actuallyPrintingNames();
}
printNames(beatles);

// Paul was found at index 0
// George was found at index 1
// John was found at index 2
// Ringo was found at index 3

// actuallyPrintingNames function runs through beatles array, name is const so it doesnt change

// Problem 9
// Why did the code produce that output? Explain why each console.log looks the way it does.

const planet = {
	name:"Jupiter",
	milesFromSun: 49849,
	mass: 393983,
            composition: ["gas", "liquid", "oxygen"]
}
const planetCopy = {...planet}
console.log(planet.composition[0] === planetCopy.composition[0]) 
console.log(planet === planetCopy)

// true, false, composition element array in planet and planetcopy are the same so true
// comparing planet object with planetcopy objcet, but planetcopy is only making shallowcopy of planet, they are also two distinct objects so they will always prove false