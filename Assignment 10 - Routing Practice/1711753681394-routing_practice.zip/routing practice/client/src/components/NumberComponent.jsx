import React from 'react'
import { useParams } from 'react-router-dom';


const Number = (props) => {
    const {num} = useParams();

    return (
        <div>
            {
                isNaN(num)? 
                <h1>Word: {num}</h1>:
                <h1>Number: {num}</h1>
            }
        </div>
    );
}

export default Number;