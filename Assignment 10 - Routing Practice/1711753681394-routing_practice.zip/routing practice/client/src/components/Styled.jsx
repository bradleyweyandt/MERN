import React from 'react';
import { useParams } from 'react-router-dom';

const HelloBlueRed = () => {
    const {num, color, background } = useParams();
    return (
        <div style = {{
            height: '100px',
            color: color,
            backgroundColor: background
        }}>
            <h1>{num}</h1>
        </div>
    )
}

export default HelloBlueRed;