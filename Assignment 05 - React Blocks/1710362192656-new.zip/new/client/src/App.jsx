import { useState } from 'react';
import Header from './components/Header.jsx';
import Navigation from './components/Navigation.jsx';
import MainContent from './components/MainContent.jsx';
import './App.css'
import Advertisement from './components/Advertisement.jsx';

function App() {
  return (
    <div>
      <Header />
      <div className="container">
      <Navigation />
      <MainContent />
    </div></div>
  );
}

export default App;