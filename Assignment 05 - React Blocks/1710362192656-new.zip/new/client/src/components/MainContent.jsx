import React from 'react';
import Subcontent from './Subcontent';
import Advertisement from './Advertisement';
import '../assets/css/MainContent.module.css';

function MainContent() {
  return (
    <div className="main-content">
      <div className="subcontents">
        <Subcontent />
        <Subcontent />
        <Subcontent />
      </div>
      <Advertisement />
    </div>
  );
}

export default MainContent;