import React from 'react';
import styles from '../assets/css/Header.module.css';

function Header() {
  return (
  <div className={styles.header}>
  <h1>Header Content</h1>
  </div>
  )
}

export default Header;