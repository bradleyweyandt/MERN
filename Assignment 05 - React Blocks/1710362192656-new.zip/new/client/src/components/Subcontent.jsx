import React from 'react';
import styles from '../assets/css/Subcontent.module.css';

const Subcontent = () => {
  return (
    <div className={styles.subcontent}>
      <h1>Subcontent</h1>
    </div>
  )
}

export default Subcontent
