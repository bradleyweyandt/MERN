import React from 'react';
import styles from '../assets/css/Navigation.module.css';

const Navigation = () => {
  return (
    <div className={styles.navigation}>
      <h1>Navigation Content</h1>
    </div>
  )
}

export default Navigation
