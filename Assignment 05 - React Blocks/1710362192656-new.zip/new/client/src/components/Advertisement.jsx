import React from 'react';
import styles from '../assets/css/Advertisement.module.css';

const Advertisement = () => {
  return (
    <div className={styles.advertisement}>
      <h1>Advertisement</h1>
    </div>
  )
}

export default Advertisement
