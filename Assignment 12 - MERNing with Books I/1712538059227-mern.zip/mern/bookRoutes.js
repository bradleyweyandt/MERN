const express = require('express');
const router = express.Router();

// Import Book model
const Book = require('./bookschema');

// (POST)
router.post('/books', async (req, res) => {
  try {
    const book = new Book(req.body);
    await book.save();
    res.status(201).send(book);
  } catch (error) {
    res.status(400).send(error);
  }
});

// (GET)
router.get('/books', async (req, res) => {
  try {
    const books = await Book.find();
    res.send(books);
  } catch (error) {
    res.status(500).send(error);
  }
});

//  (GET)
router.get('/books/:id', async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) {
      return res.status(404).send({ message: 'Book not found' });
    }
    res.send(book);
  } catch (error) {
    res.status(500).send(error);
  }
});

//  (PUT)
router.put('/books/:id', async (req, res) => {
  try {
    const book = await Book.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!book) {
      return res.status(404).send({ message: 'Book not found' });
    }
    res.send(book);
  } catch (error) {
    res.status(400).send(error);
  }
});

// (DELETE)
router.delete('/books/:id', async (req, res) => {
  try {
    const book = await Book.findByIdAndDelete(req.params.id);
    if (!book) {
      return res.status(404).send({ message: 'Book not found' });
    }
    res.send(book);
  } catch (error) {
    res.status(500).send(error);
  }
});

module.exports = router;