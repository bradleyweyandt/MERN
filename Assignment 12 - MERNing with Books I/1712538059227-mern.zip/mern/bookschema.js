const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const bookSchema = new Schema({
  title: {
    type: String,
    required: [true, 'Title is required'],
    minlength: [2, 'Title must be at least 2 characters long'],
    maxlength: [255, 'Title cannot exceed 255 characters'],
  },
  author: {
    type: String,
    required: [true, 'Author is required'],
    minlength: [5, 'Author name must be at least 5 characters long'],
    maxlength: [255, 'Author name cannot exceed 255 characters'],
  },
  pages: {
    type: Number,
    required: [true, 'Pages is required'],
    min: [1, 'Number of pages must be at least 1'],
  },
  isAvailable: {
    type: Boolean,
    default: false,
  },
}, { timestamps: true }); 


const Book = mongoose.model('Book', bookSchema);


module.exports = Book;