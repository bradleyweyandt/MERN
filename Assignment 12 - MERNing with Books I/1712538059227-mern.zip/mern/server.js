const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const dbConnect = require('./config/mongoose.config.js');
const bookRoutes = require('./bookRoutes'); 

const app = express();

app.use(express.json());
app.use(cors()); 
dotenv.config();


const PORT = process.env.PORT || 3000;

dbConnect();

app.use('/api', bookRoutes);

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
