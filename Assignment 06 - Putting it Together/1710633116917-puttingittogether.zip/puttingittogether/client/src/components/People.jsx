import React, { useState } from 'react';

const People = ({ firstName, lastName, initialAge, hairColor }) => {
  const [age, setAge] = useState(initialAge);

  const increaseAge = () => {
    setAge(age + 1);
  };

  return (
    <div>
      <h2>{lastName}, {firstName}</h2>
      <p>Age: {age}</p>
      <p>hair Color: {hairColor}</p>
      <button onClick={increaseAge}>Birthday Button for {firstName} {lastName}</button>
    </div>
  );
};

export default People;