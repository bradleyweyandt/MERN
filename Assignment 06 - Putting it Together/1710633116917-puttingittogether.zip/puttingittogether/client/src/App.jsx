import React from 'react';
import People from './components/People.jsx';
import './App.css';

const App = () => {
  return (
    <div className="container">
      <div className="info-card">
        <People firstName="Jane" lastName="Doe" initialAge={45} hairColor="Black" />
      </div>
      <div className="info-card">
        <People firstName="Smith" lastName="John" initialAge={88} hairColor="Brown" />
      </div>
    </div>
  );
};

export default App;
