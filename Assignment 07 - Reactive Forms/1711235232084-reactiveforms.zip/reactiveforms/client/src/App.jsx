import React, { useState } from 'react';
import './App.css';

function Form() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const [errors, setErrors] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
    setErrors({
      ...errors,
      firstName: name === 'firstName' && value.length < 2 ? 'First name must be at least 2 characters' : '',
      lastName: name === 'lastName' && value.length < 2 ? 'Last name must be at least 2 characters' : '',
      email: name === 'email' && value.length < 8 ? 'Email must be at least 8 characters' : '',
      password: name === 'password' && value.length < 8 ? 'Password must be at least 8 characters' : '',
      confirmPassword: name === 'confirmPassword' && value !== formData.password ? 'Passwords do not match' : '',
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setFormData({
      firstName: '',
      lastName: '',
      email: '',
      password: '',
      confirmPassword: '',
    });
  };

  return (
    <div className="form-container">
      <h2 className="form-heading">Welcome!</h2>
      <form className="form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="firstName">First Name:</label>
          <input
            type="text"
            id="firstName"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
          />
          <p className="error">{errors.firstName}</p>
        </div>
        <div className="form-group">
          <label htmlFor="lastName">Last Name:</label>
          <input
            type="text"
            id="lastName"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
          />
          <p className="error">{errors.lastName}</p>
        </div>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
          />
          <p className="error">{errors.email}</p>
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
          />
          <p className="error">{errors.password}</p>
        </div>
        <div className="form-group">
          <label htmlFor="confirmPassword">Confirm Password:</label>
          <input
            type="password"
            id="confirmPassword"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleChange}
          />
          <p className="error">{errors.confirmPassword}</p>
        </div>
        <button type="submit">Create User</button>
      </form>
    </div>
  );
}

export default Form;